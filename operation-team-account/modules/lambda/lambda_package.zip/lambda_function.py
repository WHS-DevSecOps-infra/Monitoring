def lambda_handler(event, context):
    # TODO: Slack 알림, OpenSearch 색인 로직 구현
    print("Event:", event)
    return {"status": "ok"}